from distutils.core import setup

setup(
    name = "detectionlib",
    version = "1.2",
    author = "xiaoyang",
    description = "Object detection lib",
    packages = ["DetectionService", "DetectionService.data", "DetectionService.protos", "DetectionService.uploads", "DetectionService.utils"],
    data_files = [('DetectionService/data', ['DetectionService/data/mscoco_label_map.pbtxt'])],
)
