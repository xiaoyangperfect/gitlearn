from distutils.core import setup

setup(
    name = "detectionlib",
    version = "1.0",
    author = "xiaoyang",
    description = "Object detection lib",
    packages = ["DetectionService", "DetectionService.data", "DetectionService.protos", "DetectionService.uploads", "DetectionService.utils"],
)
